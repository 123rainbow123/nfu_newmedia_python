pick_a_color_4web


		英文项目名称，必需取名合理，是目录名亦是.py後端程序（此行完成後应删）
# 简介 
选取的颜色，操练Python语言开发练习：使用flask


		中文简介项目内容（此行完成後应删）

## 输入：
用户输入变数1（型态1）丶变数2（型态2）丶
## 输出：
用户得到输出结果为：
## 从输入到输出，本组作品使用了：
### 模块
* [folium](https://github.com/python-visualization/folium)
* [opencv](http://opencv.org/)
### 数据
* [简中CLDR localenames](https://github.com/unicode-cldr/cldr-localenames-modern/blob/master/main/zh-Hans/territories.json)
### API
* [github](https://api.github.com/)

## 作者成员：
见[_team_.tsv](_team_/_team_.tsv)


		成员列表，统计用，一人一行，输入Github 帐户名即可（此行完成後应删）
