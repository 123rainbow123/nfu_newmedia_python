# 中山大学南方学院 2016 - 2017 
# 文学与传媒系【Python】分组项目

说明：
* 详细内容见[pick_a_color_4web](pick_a_color_4web)，请各组选定一代表用户做主（owner），fork此仓库名称repo为nfu_newmedia_python的仓库，直接在此forked仓库内新创个目录。建议可以直接复制pick_a_color_4web改档名。
* 请填表 [list_projects.tsv](list_projects.tsv)（以tab隔开，一组一行）
 
